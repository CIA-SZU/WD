function [Winner,Loser] = WinerUpdate1(Population,Q)

    N = size(Population.objs,1);
    D_scores = RV_LC(Population, Q);
    [~, idx] = sort(D_scores, 'descend');
    Winner = idx(1:N/2);
    Loser = setdiff((1:1:N), Winner);
    Loser = Loser(randperm(numel(Loser),length(Winner)));

end