function D_scores = RV_LC(F, H)
% RV_LC_MultiObjective - 独立的多目标多样性评估方法
%
% 输入参数:
%   F: 目标值矩阵 (N x M)，N为种群大小，M为目标函数个数
%   H: 参考向量划分系数
%   options: 可选参数结构体
%     .normalize: 是否归一化目标值 (默认: true)
%     .visualize: 是否可视化结果 (默认: false)
%     .distance_metric: 距离度量 ('euclidean', 'cosine', 默认: 'euclidean')
%
% 输出参数:
%   D_scores: 每个个体的多样性分数 (N x 1)
%   assignment: 每个个体分配的参考向量索引 (N x 1)
%   V: 生成的参考向量矩阵 (K x M)

    %% 生成参考向量
     PopObj=F.objs;
     [N,M]  = size(PopObj);
     [W,H] = UniformPoint(H,M);
    
    %% 将个体分配到参考向量   
    Angle = acos(1-pdist2(PopObj,W,'cosine'));
    [~,associate] = min(Angle,[],2);
    
    F_norm = normalize_minmax(PopObj);
    %% 步骤4: 计算局部拥挤度 (多样性分数)
    D_scores = compute_local_crowding(F_norm, associate);
    
    %% 步骤5: 奖励边界个体
    D_scores = reward_extreme_individuals_multi(F_norm, D_scores);
    
end


function PopObj_norm = normalize_minmax(PopObj)

    [N, M] = size(PopObj);
    PopObj_norm = zeros(N, M);
    
    for j = 1:M
        col_data = PopObj(:, j);
        min_val = min(col_data);
        max_val = max(col_data);
        range_val = max_val - min_val;             
         PopObj_norm(:, j) = (col_data - min_val) / range_val;      
    end
end

%% 多目标局部拥挤度计算
function D_scores = compute_local_crowding(PopObj_norm, assignment)
% 计算局部拥挤度（使用欧氏距离）
% 输入:
%   PopObj_norm - 归一化目标值矩阵 (N×M)
%   assignment - 个体分配的参考向量索引 (N×1)
% 输出:
%   D_scores - 局部拥挤度分数 (N×1)

    [N, M] = size(PopObj_norm);
    K = size(assignment, 1); % 参考向量数量
    D_scores = inf(N, 1); % 初始化为无穷大
    
    fprintf('计算局部拥挤度（欧氏距离）...\n');
    
    % 对每个参考向量扇区进行处理
    for niche_id = 1:K
        % 找到属于当前扇区的所有个体
        indices = find(assignment == niche_id);
        num_in_niche = length(indices);
        
        if num_in_niche == 0
            % 空扇区：跳过
            continue;
            
        elseif num_in_niche == 1
            % 扇区内只有一个个体：赋予高分数
            D_scores(indices) = 10.0;
            
        else
            % 扇区内有多个个体：计算局部拥挤度
            F_niche = PopObj_norm(indices, :);
            
            % 计算扇区内所有个体两两之间的欧氏距离
            dist_matrix = pdist2(F_niche, F_niche, 'euclidean');
            
            % 将对角线设为inf，避免自己到自己的距离
            dist_matrix(logical(eye(num_in_niche))) = 0;
            
            % 找到每个个体在该扇区内的最近邻距离
            min_dists = mean(dist_matrix, 2);
            D_scores(indices) = min_dists;
        end
    end
    
    % 处理无穷大值（如果存在）
    inf_mask = isinf(D_scores);
    if any(inf_mask)
        finite_values = D_scores(~inf_mask);
        if ~isempty(finite_values)
            D_scores(inf_mask) = max(finite_values) * 1.1;
        else
            D_scores(inf_mask) = 1.0;
        end
    end
    
    fprintf('局部拥挤度计算完成。范围: [%.4f, %.4f]\n', min(D_scores), max(D_scores));
end

%% 多目标边界个体奖励
function D_scores = reward_extreme_individuals_multi(F_norm, D_scores)
% 识别并奖励边界个体
    
    [N, M] = size(F_norm);
    boundary_reward = 2.0; % 边界奖励系数
    
    for obj_idx = 1:M
        % 找到每个目标的最小值和最大值个体
        [~, min_idx] = min(F_norm(:, obj_idx));
       % [~, max_idx] = max(F_norm(:, obj_idx));
        
        % 奖励边界个体
        D_scores(min_idx) = D_scores(min_idx) * boundary_reward;
       % D_scores(max_idx) = D_scores(max_idx) * boundary_reward;
        
        %fprintf('边界奖励: 目标%d - 最小值个体%d, 最大值个体%d\n', ...
       %         obj_idx, min_idx, max_idx);
    end
end



