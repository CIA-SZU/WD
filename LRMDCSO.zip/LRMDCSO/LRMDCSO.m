classdef LRMDCSO< ALGORITHM
% <multi> <real> <robust>
% Q  ---  10 --- Number of solutions for decision variable assortment

    methods
        function main(Algorithm,Problem)
            Q = Algorithm.ParameterSet(10);
            %% Generate random population
           % V= UniformPoint(Problem.N,Problem.M);
            %[W,Problem.N] = UniformPoint(Problem.N,Problem.M);

            X= UniformPoint((Problem.N)/2,Problem.M);
      
            Population    = Problem.Initialization();
           [Population,~] = EnvironmentalSelectionSPEA2(Population,Problem.N);
            
            
            z1        = min(Population.objs,[],1);

           
            while Algorithm.NotTerminated(Population)

                Angle = acos(1-pdist2(Population.objs,X,'cosine'));
                  [~,associate] = min(Angle,[],2);
                  H = size(X, 1); % 参考向量总数

                  % 计算每个参考向量被绑定的个体数量
                  binding_count = zeros(H, 1);
                  for i = 1:H
                    binding_count(i) = sum(associate == i);
                  end
                   bound_vectors = find(binding_count > 0);
              
               z1          = min([z1;Population.objs],[],1);

               b=0.06*(Problem.N);
            if  (length(bound_vectors)<= b)
             
                
               [Winset,Loseset] = WinerUpdate1(Population,Q);
               Offspring      = Operator1(Problem,Population(Loseset),Population(Winset'));
               
                    PopDec = Offspring.decs;
                    Offspring = Problem.Perturb(PopDec,1);
                   [Population,~] = EnvironmentalSelectionSPEA2([Population,Offspring],Problem.N);
               
            else
 
                [Winset,Loseset] = WinerUpdate2(Population,z1,Problem);
                Offspring      = Operator(Problem,Population(Loseset),Population(Winset'));
               
                   P1=[Population,Offspring];
                   popdec=P1.decs;
                   P1 = Problem.Perturb(popdec,1);
                   PopObjV=P1.objs;
                   [Population,~] = EnvironmentalSelection1([Population,Offspring,P1],Problem.N,[Population.objs;Offspring.objs;PopObjV]);
              
               
             end
              
             end


         
            
        end
    end
end