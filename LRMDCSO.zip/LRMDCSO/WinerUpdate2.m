function [Winner,Loser] = WinerUpdate2(Population,z,Problem)

    
  PopObj=Population.objs;

    if length(Population) >= 2
                    N=length(Population);
     else
                    N=1;
     end
 %% Calculate angles between solutions and ASF
    %Angle = acos(1-pdist2(PopObj,PopObj,'cosine'));
    %Angle(logical(eye(length(Angle)))) = inf;

    ASF = max((PopObj-z).*sum(PopObj,2)./PopObj,[],2);
   

   for i = 1 : length(Population)
        PopX         = Problem.Perturb(Population(i).dec,5);
        PopObjV(i,:) = mean(abs(PopX.objs-Population(i).obj),1);
        
   end
   
   performance_changes = sum(PopObjV, 2);

   
       
    alpha = (ASF_mean - min_ASF) / (max_ASF - min_ASF);
        alpha = max(0, min(1, alpha)); % 限制在合理范围
    
      
    C_norm = normalize_scores(ASF);
    R_norm = normalize_scores(performance_changes);
   
    S = alpha * C_norm + (1 - alpha) * R_norm;
   
   fprintf('a值，C_norm，R_norm: [%.4f]\n', alpha);
    % [~, idx] = sort(S);
    % Winner = idx(1:N/2);
    % Loser = setdiff((1:1:N), Winner);
    % Loser = Loser(randperm(numel(Loser),length(Winner)));
      % 随机打乱个体顺序以确保随机配对
    random_order = randperm(N);
    shuffled_scores = S(random_order);
    shuffled_indices = random_order;
  %  winners = zeros(1, N/2);
    %losers = zeros(1, N/2);

    % 两两比较
    for i = 1:2:N
        pair_index = (i + 1) / 2;
        idx1 = i;
        idx2 = i + 1;

        % 比较两个个体的得分
        if shuffled_scores(idx1) <= shuffled_scores(idx2)
            Winner(pair_index) = shuffled_indices(idx1);
            Loser(pair_index) = shuffled_indices(idx2);
        else
            Winner(pair_index) = shuffled_indices(idx2);
            Loser(pair_index) = shuffled_indices(idx1);
        end
    end
end

function norm_scores = normalize_scores(scores)
% 归一化得分到[0,1]范围
    min_score = min(scores);
    max_score = max(scores);
    
    if max_score - min_score < 1e-10
        norm_scores = ones(size(scores)); % 防止除零
    else
        norm_scores = (scores - min_score) / (max_score - min_score);
    end
end