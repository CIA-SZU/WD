function Offspring = Operator1(Problem,Loser,Winner)

    LoserDec  = Loser.decs;
    WinnerDec = Winner.decs;
    [N,D]     = size(LoserDec);
	LoserVel  = Loser.adds(zeros(N,D));
    WinnerVel = Winner.adds(zeros(N,D));

    while true
        % 生成一个随机排列
        shuffled_indices = randperm(N);

        % 检查是否满足错排条件
        if all(shuffled_indices ~= 1:N)
            WinnerDec1 = WinnerDec(shuffled_indices,:);  % 如果满足错排条件，更新新数组
            break;  % 跳出循环
        end
    end
   

    %Problem   = PROBLEM.Current();
    
    %% updating
    r1     = repmat(rand(N,1),1,D);
    r2     = repmat(rand(N,1),1,D);
    r3     = repmat(rand(N,1),1,D);
    
    OffVel = r1.*LoserVel + r2.*WinnerDec+r3.*WinnerDec1-(r2+r3).*LoserDec;
    OffDec = LoserDec + OffVel;
    OffDec = [OffDec;WinnerDec];
    OffVel = [OffVel;WinnerVel];
 
    %% PM
    Lower  = repmat(Problem.lower,2*N,1);
    Upper  = repmat(Problem.upper,2*N,1);
    disM   = 20;
    Site   = rand(2*N,D) < 1/D;
    mu     = rand(2*N,D);
    temp   = Site & mu<=0.5;
    OffDec       = max(min(OffDec,Upper),Lower);
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                   (1-(OffDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp  = Site & mu>0.5; 
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                   (1-(Upper(temp)-OffDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
	Offspring = Problem.Evaluation(OffDec,OffVel);
end